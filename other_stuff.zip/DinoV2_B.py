import torch
from transformers import AutoImageProcessor, AutoModel
from PIL import Image

# 0. Pick device
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Using device:", device)

# 1. Load processor & model, then move model to GPU
checkpoint = "facebook/dinov2-base"
processor  = AutoImageProcessor.from_pretrained(checkpoint)
model      = AutoModel.from_pretrained(checkpoint).to(device)
model.eval()

# 2. Prepare your image
img = Image.open(r"/home/deadcrow/Desktop/PaperImages/2dshapes/Selected6.jpg").convert("RGB")

# 3. Build inputs and move them to the same device
inputs = processor(images=img, return_tensors="pt")           # yields a BatchEncoding
inputs = {k: v.to(device) for k, v in inputs.items()}         # e.g. {"pixel_values": tensor}

# 4. Forward‐pass & grab [CLS] token
with torch.no_grad():
    outputs     = model(**inputs)
    last_hidden = outputs.last_hidden_state                   # (1, N_patches+1, hidden_dim)
    cls_token   = last_hidden[:, 0]                           # (1, hidden_dim)
    embedding   = torch.nn.functional.normalize(cls_token, dim=-1)

print("Embedding shape:", embedding.shape)