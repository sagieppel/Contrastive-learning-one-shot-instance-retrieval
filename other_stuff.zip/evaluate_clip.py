import os.path
import Image2desc_CLIP as Get_desc
#import Image2desc_DINO_V2 as Get_desc
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torchvision import models
import numpy as np
import reader_LAST_standart as reader_LAST
import reader_2Dshape
import model_fully_connected as Model
import cv2
import LossFunction

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
# model = ContrastiveModel().to(device)
model=Model.Net()
optimizer = optim.AdamW(model.parameters(), lr=1e-4, weight_decay=1e-4)
desc_maker = Get_desc.desc_maker()
import Reade_CLASS_FOR_CONTRASTIVE as reader_eval
########################################################################################################################################################
################################################################################################################################################

def evaluate(reader_test):

   # print("\n*************************Testing**************************************************************************\n")
    model.eval() # important Eval was off and augment was on can have maijor implications
    correct, total = 0, 0


    reader_test.indx=0
    with torch.no_grad():
        ii = 0
        for i in range(5):
            reader_test.indx = 0

            while(True):
                    ii+=1
                #try:
                   # imgs, lbls, xy, files = reader_test.readbatch(nmaps=1, nregions=3, ninst=2,augment=True)
                    success, imgs = reader_test.get_next_question()
                    desc = desc_maker.get_desc(imgs)
                    desc = desc.squeeze()
                    if not success: break
                    # imgs = torch.tensor(imgs).permute(0, 3, 1, 2).float().to(device) / 255.0
                    # lbls = torch.tensor(lbls).to(device)
             #       *****************************************************************************************
             #        for i in range(imgs.shape[0]):
             #            cv2.imshow(str(i) + "Eval Label:" + str(lbls[i]), imgs[i])  # files[i]["di"]+
             #        cv2.waitKey()
             #        cv2.destroyAllWindows()
              #      **********************************************************************************************
                    embeddings = model(desc)
                    similarities = torch.mm(embeddings, embeddings.T)
                    similarities -= torch.eye(similarities.shape[0]).cuda() * 10
                    predictions = torch.argmax(similarities, dim=1)
                    predictions=predictions.detach().cpu().numpy()
                    total+=1
                    if predictions[0]==1:
                                 correct += 1
                                 reader_test.add_correct()
                    else:
                                 reader_test.add_incorrect()
                    print(ii,") accuracy",correct/total)
                    reader_test.write_correct("STATITICS.xls")
                    # *****************************************************************************************
                    # ttt=(lbls == lbls[predictions])
                    # for i in range(imgs.shape[0]):
                    #        cv2.imshow(str(i) + "Eval Label:" + str(lbls[i])+"  match "+str(ttt[i]), imgs[i])  # files[i]["di"]+
                    #        cv2.waitKey()
                    #        cv2.destroyAllWindows()
            #      **********************************************************************************************
    return correct / total
################################################################################################################################################


reader=reader_eval.make_quize(main_dir="/home/deadcrow/Desktop/RealImages_Test/Shrinko512", max_img_per_instance=2000, max_img_total=400,max_instance_per_class=4000)

saved_model=("logs_3D_shapes_CLIP_4Layers/12000.torch")#70000.torch"#52000.torch"#%26000.torch" #10k
#model=torch.load(saved_model,weights_only=True)
model.load_state_dict(torch.load(saved_model,weights_only=True))
#========================================================================
#Example usage:
evaluate(reader_test=reader) # remember eval and augment