import torch
from PIL import Image
from torchvision import transforms

# 1. Load a pretrained DINOv2 ViT‑B/14 backbone
model = torch.hub.load('facebookresearch/dinov2', 'dinov2_vitb14')
model.eval()

# 2. ImageNet‑style preprocessing
transform = transforms.Compose([
    transforms.Resize(256),
    transforms.CenterCrop(224),
    transforms.ToTensor(),
    transforms.Normalize(
        mean=(0.485, 0.456, 0.406),
        std=(0.229, 0.224, 0.225)
    ),
])

# 3. Load & preprocess
img = Image.open('/home/deadcrow/Desktop/PaperImages/2dshapes/Selected6.jpg').convert('RGB')
x   = transform(img).unsqueeze(0)  # shape: (1, 3, 224, 224)

# 4. Forward‐pass & extract CLS token
with torch.no_grad():
    # `.forward_features` returns a tensor of shape (B, D, N_patches+1)
    feats     = model.forward_features(x)   # e.g. (1, 768, 197)
    cls_token = feats[:, :, 0]              # pick the first token → (1, 768)
    # note: some DINOv2 variants use registry or patch‐norm heads;
    # check `dir(model)` if this fails, or call `model.embed()` if available.

# 5. L2‐normalize
embedding = torch.nn.functional.normalize(cls_token, dim=-1)  # (1, 768)

print("Embedding shape:", embedding.shape)