import numpy as np
import torch
from PIL import Image
import open_clip
import torch
from transformers import AutoImageProcessor, AutoModel
from PIL import Image

# 0. Pick device
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Using device:", device)

class desc_maker():
    def __init__(self):
        print("Loading open DINO_V2")

        # 1. Load processor & model, then move model to GPU
        self.checkpoint = "facebook/dinov2-base"
        self.processor = AutoImageProcessor.from_pretrained(self.checkpoint)
        self.model = AutoModel.from_pretrained(self.checkpoint).to(device)
        self.model.eval()



    def get_desc(self,batch):
        # 2. Prepare your image
        # 2. Prepare your image
        descs = []
        for i in range(batch.shape[0]):
           # descs.append(self.get_im_dec(batch[i]))
            img =Image.fromarray(batch[i])

            # 3. Build inputs and move them to the same device
            inputs = self.processor(images=img, return_tensors="pt")  # yields a BatchEncoding
            inputs = {k: v.to(device) for k, v in inputs.items()}  # e.g. {"pixel_values": tensor}

            # 4. Forward‐pass & grab [CLS] token
            with torch.no_grad():
                outputs = self.model(**inputs)
                last_hidden = outputs.last_hidden_state  # (1, N_patches+1, hidden_dim)
                cls_token = last_hidden[:, 0]  # (1, hidden_dim)
                embedding = torch.nn.functional.normalize(cls_token, dim=-1)
                descs.append(embedding)
        return torch.concatenate(descs,0)

