import numpy as np
import torch
from PIL import Image
import open_clip


class desc_maker():
    def __init__(self):
        print("Loading open Clip")
        self.model, _, self.preprocess = open_clip.create_model_and_transforms('ViT-B-32', pretrained='laion2b_s34b_b79k')
        self.model.eval()  # model in train mode by default, impacts some models with BatchNorm or stochastic depth active

    # def get_desc(self,imgs):
    #     images=[]
    #     for i in range(imgs.shape[0]):
    #           images.append(self.preprocess(Image.fromarray(imgs[i])).unsqueeze(0))
    #     images=torch.concatenate(images,axis=0)
    #
    #     with torch.no_grad(), torch.autocast("cuda"):
    #         image_features = self.model.encode_image(images)
    #         image_features /= image_features.norm(dim=-1, keepdim=True)
    #         return  image_features


    def get_im_dec(self,im):
        image = self.preprocess(Image.fromarray(im)).unsqueeze(0)


        with torch.no_grad(), torch.autocast("cuda"):
            image_features = self.model.encode_image(image)
            image_features /= image_features.norm(dim=-1, keepdim=True)
            return  image_features

    def get_desc(self,batch):
        descs=[]
        for i in range(batch.shape[0]):
            descs.append(self.get_im_dec(batch[i]))
        return torch.concatenate(descs,0)

