import torch
import torch.nn as nn
import torch.nn.functional as F

device = torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu")
class Net(nn.Module):
    def __init__(self, input_size=512, hidden_sizes=[512,512,512,512,512], dropout_prob=0.0):#
        """
        input_size: int - Size of the input vector
        hidden_sizes: list of 6 ints - Sizes of the 6 hidden layers
        output_size: int - Size of the final output
        dropout_prob: float - Optional dropout probability (default: 0.0 = no dropout)
        """
        super(Net, self).__init__()


        # Define the 7 linear layers
        self.fc1 = nn.Linear(input_size, hidden_sizes[0])
        self.fc2 = nn.Linear(hidden_sizes[0], hidden_sizes[1])
        self.fc3 = nn.Linear(hidden_sizes[1], hidden_sizes[2])
        self.fc4 = nn.Linear(hidden_sizes[2], hidden_sizes[3])
        self.fc5 = nn.Linear(hidden_sizes[3], hidden_sizes[4])


        # Optional dropout
        self.dropout = nn.Dropout(dropout_prob)
        self.to(device)

    def forward(self, x):
        x=x.to(device)
        x = F.relu(self.fc1(x))
        #x = self.dropout(x)
        x = F.relu(self.fc2(x))
      #  x = self.dropout(x)
        x = F.relu(self.fc3(x))
     #   x = self.dropout(x)
        x = F.relu(self.fc4(x))
     #   x = self.dropout(x)

        x = F.normalize(x, dim=1)  # L2 normalize embeddings

        return x

