import os.path
import Image2desc_CLIP as Get_desc
#import Image2desc_DINO_V2 as Get_desc
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torchvision import models
import numpy as np
# import reader_LAST_standart as reader_LAST
import reader_2Dshape

import reader_LAST_3Dobjects as reader_LAST

import model_fully_connected as Model
import cv2
import LossFunction

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
# model = ContrastiveModel().to(device)
model=Model.Net()
optimizer = optim.AdamW(model.parameters(), lr=1e-4, weight_decay=1e-4)
desc_maker = Get_desc.desc_maker()

########################################################################################################################################################

def train(reader_train, readers_test, log_dir="logs/", num_epochs=100000, eval_every=100,start_from=0):
    if not os.path.exists(log_dir): os.mkdir(log_dir)
    eval_file = log_dir + '/evaluation_results.txt'
    fl=open(eval_file,"w"); fl.close()
    mean_loss = 0
    model.train()
    step = 0
    mean_accuracy= 0
    for epoch in range(start_from,num_epochs):
       # while True:
        #    try:
              #  imgs, lbls, xy, files = reader_train.readbatch(nmaps=1, nregions=4, ninst=2,augment=False)
                imgs, lbls, files = reader_train.readbatch(ncluster=5, ninst=2,augment=True)
                desc=desc_maker.get_desc(imgs)
                desc = desc.squeeze()
       #*****************************************************************************************
                # for i in range(imgs.shape[0]):
                #     cv2.imshow(str(i) + "Train  Label:" + str(lbls[i]), imgs[i])  # files[i]["di"]+
                # cv2.waitKey()
                # cv2.destroyAllWindows()
       #**********************************************************************************************
                # imgs = torch.tensor(imgs).permute(0, 3, 1, 2).float().to(device) / 255.0
                # lbls = torch.tensor(lbls).to(device)
                optimizer.zero_grad()
                embeddings = model(desc)
                loss,accuracy =LossFunction.LossCosineSimilarity(embeddings, lbls, temp=0.2)
                #
                loss.backward() #***********
                optimizer.step()#***********

                mean_loss = mean_loss*0.99+loss.detach().cpu()*0.01
                mean_accuracy=mean_accuracy*0.99+accuracy*0.01
                if epoch%20==0:
                          print(epoch,"mean loss",mean_loss,"loss",loss, " accuracy",accuracy," mean accuracy",mean_accuracy)
                if step % eval_every == 0:# and step>0:
                    for num_choices in [3,5]:  # [2,3,5,20]:
                        txt = "\n" + str(epoch) + ") \tNumber of Choices\t" + str(num_choices * 2 - 1) + "\t"
                        for rd_nm in readers_test:
                            print("Evaluating", rd_nm)
                            res = evaluate(readers_test[rd_nm], num_choices=num_choices)
                            print(str(res))
                            txt += rd_nm + "=\t" + str(res) + "\t"
                        print(txt)
                        fl = open(eval_file, "a+")
                        fl.write(txt)
                        fl.close()
                step += 1
                if step % 2000 == 0:
                          torch.save(model.state_dict(), log_dir+"//"+str(step)+".torch")
                if step % 500 == 0:
                    torch.save(model.state_dict(), log_dir + "//defult.torch")
            # except StopIteration:
            #     break
################################################################################################################################################

def evaluate(reader_test,num_choices=3):

   # print("\n*************************Testing**************************************************************************\n")
    model.eval()
    correct, total = 0, 0
    with torch.no_grad():
        for ii in range(70):
            #try:
               # imgs, lbls, xy, files = reader_test.readbatch(nmaps=1, nregions=3, ninst=2,augment=True)
                imgs, lbls, files = reader_test.readbatch(ncluster=num_choices, ninst=2)
                desc = desc_maker.get_desc(imgs)
                desc = desc.squeeze()
                # imgs = torch.tensor(imgs).permute(0, 3, 1, 2).float().to(device) / 255.0
                # lbls = torch.tensor(lbls).to(device)
         #       *****************************************************************************************
         #        for i in range(imgs.shape[0]):
         #            cv2.imshow(str(i) + "Eval Label:" + str(lbls[i]), imgs[i])  # files[i]["di"]+
         #        cv2.waitKey()
         #        cv2.destroyAllWindows()
          #      **********************************************************************************************
                embeddings = model(desc)
                similarities = torch.mm(embeddings, embeddings.T)
                similarities -= torch.eye(similarities.shape[0]).cuda() * 10
                predictions = torch.argmax(similarities, dim=1)
                predictions=predictions.detach().cpu().numpy()
                correct += (lbls == lbls[predictions]).sum()
                total += len(lbls)
            # except StopIteration:
            #     break
    #print(f"Test Accuracy: {correct / total:.4f}")
    #print("\n***************************************************************************************************\n")
    model.train()
    return correct / total
#####################################################################################################################################################


texture_dir=""

datasets=[

    ]

tst_dr =  "/media/deadcrow/6TB/python_project/Can_LVM_See3D/All_Tests"

#"/media/deadcrow/SSD_480GB/segment_anything/2D_Shape_Matching_Tests//"#
#"/media/deadcrow/SSD_480GB/segment_anything/2D_Shape_Matching_Tests//"
# "/media/deadcrow/SSD_480GB/segment_anything/2D_Shape_Matching_Tests//"

# r"/media/deadcrow/6TB/python_project/Can-large-vision-language-models-understand-materials-and-textures/3D_PBR_Materials_matching_Test/"

train_set = "10_Everythiong_Different_New_Big_Train_SEt"
# 3d shapes: /10_Everythiong_Different_New_Big_Train_SEt
# 2D shape "Rotation_Texture_Background_Train"
# 2D texture:"AllDifferent_Traininig"
log_dir="logs_3D_shapes_CLIP_Desc"#4Layers"#5Layersw4"
# pbr"AllDifferent_Train"

for dr in os.listdir(tst_dr):
    if os.path.isdir(tst_dr+"//"+dr+"//"):
                datasets.append({"name":dr,"main_dir":tst_dr+"//"+dr+"//"})


readers={}
for ent in datasets:
    print(" Making reader for ",ent["name"])
    if "shape_dir" in ent:
           readers[ent["name"]] = reader_2Dshape.reader(shape_dir=ent["shape_dir"],texture_dir=texture_dir)
    elif "main_dir" in ent:
        readers[ent["name"]] = reader_LAST.reader(main_dir=ent["main_dir"])




#==========================================================================
saved_model=""
start_from=0
# for ii in range(0,10000000,1000):
#   if os.path.exists(log_dir+"//"+str(ii)+".torch"):
#       saved_model = log_dir+"//"+str(ii)+".torch"
#       start_from=ii+1
# if len(saved_model)>0:
#       print("Loading model from",saved_model)
#       model.load_state_dict(torch.load(saved_model,weights_only=True))
#========================================================================
#Example usage:
train(reader_train=readers[train_set],num_epochs=120001, readers_test=readers,log_dir=log_dir,eval_every=2000,start_from=start_from)